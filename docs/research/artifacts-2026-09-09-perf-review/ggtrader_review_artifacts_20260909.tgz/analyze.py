#!/usr/bin/env python3
"""Compute paper-trading performance metrics from dumped CSVs (stdlib only).

Inputs (all produced by read-only psql dumps):
  snapshots.csv   run_date|portfolio_value|cash          (52 rows, 6/24-9/8)
  snapshots0.csv  run_date|portfolio_value|cash          (backup row for 6/23)
  mnst.csv        run_date|market_value|qty|price        (MNST per snapshot)
  spy.csv         date|close                             (DB ohlcv, ends 8/21)
  spy_marks.csv   run_date|price                         (snapshot SPY marks, 8/24+)
  trades_full.csv run_date|side|symbol|amount|reason
Outputs: metrics.json + stdout summary.
"""
import csv
import json
import math

D = "/tmp/t_f8285900/"


def load(path, sep="|"):
    rows = []
    with open(D + path) as f:
        for line in f:
            line = line.rstrip("\n").rstrip("\r")
            if not line or not line.strip():
                continue
            parts = line.split(sep)
            if len(parts) < 2 or not parts[1].strip():
                continue
            rows.append(parts)
    return rows


snaps = [(r[0], float(r[1]), float(r[2])) for r in load("snapshots.csv")]
snaps0 = [(r[0], float(r[1]), float(r[2])) for r in load("snapshots0.csv")]
# t0 = the 6/23 all-cash backup row (account inception for this deployment)
t0_date, t0_pv, t0_cash = snaps0[0]

mnst = {r[0]: (float(r[1]), float(r[2]), float(r[3])) for r in load("mnst.csv", sep="\t")}

# SPY series: DB daily closes through 8/21, then snapshot intraday marks 8/24+.
spy = {}
for r in load("spy.csv", sep="\t"):
    spy[r[0]] = float(r[1])
for r in load("spy_marks.csv", sep="\t"):
    spy[r[0]] = float(r[1])

trades = [(r[0], r[1], r[2], float(r[3]), r[4] if len(r) > 4 else "") for r in load("trades_full.csv")]

# --- MNST split correction --------------------------------------------------
# True MNST value = 2x displayed for snapshots where the broker's unapplied
# 2-for-1 split (ex 2026-08-11) is showing: 8/11-8/19 (pre-guard) and
# 8/26-9/8 (after the 14-day split lookback expired). 8/20-8/25 snapshots
# were already corrected in-table by the deployed split guard.
SPLIT_EX = "2026-08-11"
uncorrected = []
for d, (mv, qty, px) in sorted(mnst.items()):
    if d >= SPLIT_EX and mv < 1500:  # displayed at half value
        uncorrected.append(d)
corr_add = {d: mnst[d][0] for d in uncorrected}  # addition = displayed mv


def pv_series(corrected):
    out = [(t0_date, t0_pv)]
    for d, pv, cash in snaps:
        out.append((d, pv + corr_add.get(d, 0.0) if corrected else pv))
    return out


def metrics(series, label):
    dates = [s[0] for s in series]
    pvs = [s[1] for s in series]
    rets = [(dates[i], pvs[i] / pvs[i - 1] - 1) for i in range(1, len(pvs))]
    n = len(rets)
    m = sum(r for _, r in rets) / n
    var = sum((r - m) ** 2 for _, r in rets) / (n - 1)
    sd = math.sqrt(var)
    sharpe = m / sd * math.sqrt(252) if sd > 0 else float("nan")
    # max drawdown
    peak = pvs[0]
    mdd, mdd_date = 0.0, None
    for d, pv in series:
        peak = max(peak, pv)
        dd = (peak - pv) / peak
        if dd > mdd:
            mdd, mdd_date = dd, d
    cum = pvs[-1] / pvs[0] - 1
    win = sum(1 for _, r in rets if r > 0) / n
    # SPY matched over identical intervals
    spy_rets = []
    for i in range(1, len(series)):
        d0, d1 = dates[i - 1], dates[i]
        if d0 in spy and d1 in spy:
            spy_rets.append(spy[d1] / spy[d0] - 1)
    spy_cum = spy[dates[-1]] / spy[dates[0]] - 1 if dates[0] in spy and dates[-1] in spy else float("nan")
    sm = sum(spy_rets) / len(spy_rets)
    svar = sum((r - sm) ** 2 for r in spy_rets) / (len(spy_rets) - 1)
    ssd = math.sqrt(svar)
    spy_sharpe = sm / ssd * math.sqrt(252)
    return {
        "label": label,
        "n_days": n,
        "window": [dates[0], dates[-1]],
        "cum_return": cum,
        "ann_sharpe": sharpe,
        "max_drawdown": mdd,
        "max_drawdown_date": mdd_date,
        "daily_win_rate": win,
        "mean_daily": m,
        "daily_sd": sd,
        "spy_cum_same_window": spy_cum,
        "spy_ann_sharpe_same_window": spy_sharpe,
    }


raw = metrics(pv_series(False), "raw PV (as stored)")
cor = metrics(pv_series(True), "split-corrected PV")

# --- sub-windows on the corrected series ------------------------------------
s = pv_series(True)
idx = {d: i for i, (d, _) in enumerate(s)}


def sub(a, b, label):
    return metrics(s[idx[a] : idx[b] + 1], label)


w_pre = sub("2026-06-23", "2026-08-20", "pre-sweep 6/23-8/20 (corrected)")
w_post = sub("2026-08-21", "2026-09-08", "post-sweep 8/21-9/8 (corrected)")

# monthly returns (corrected)
monthly = {}
last_pm = None
for i in range(1, len(s)):
    d, pv = s[i]
    pm = d[:7]
    if pm != last_pm:
        monthly[pm] = {"start": s[i - 1][1], "end": pv}
    else:
        monthly[pm]["end"] = pv
    last_pm = pm
monthly_rets = {pm: v["end"] / v["start"] - 1 for pm, v in monthly.items()}

# --- turnover ----------------------------------------------------------------
total_buy = sum(a for _, side, _, a, _ in trades if side == "BUY")
total_sell = sum(a for _, side, _, a, _ in trades if side == "SELL")
sweep_buy = sum(a for _, side, _, a, r in trades if side == "BUY" and r == "cash_sweep")
sweep_sell = sum(a for _, side, _, a, r in trades if side == "SELL" and r == "cash_sweep")
strat_buy = total_buy - sweep_buy
strat_sell = total_sell - sweep_sell
avg_pv = sum(pv for _, pv in s) / len(s)
n_ret_days = len(s) - 1
turnover_ann = (total_buy + total_sell) / avg_pv * (252 / n_ret_days)

# --- cash drag pre-sweep -----------------------------------------------------
pre = [(d, pv, c) for d, pv, c in snaps if d <= "2026-08-21"]
avg_cash_frac = sum(c / pv for _, pv, c in pre) / len(pre)

# --- final position PnL (from last snapshot, MNST-corrected) -----------------
last_date, last_pv, last_cash = snaps[-1]
final = {
    "date": last_date,
    "pv_raw": last_pv,
    "pv_corrected": last_pv + corr_add.get(last_date, 0.0),
    "cash": last_cash,
    "cash_frac": last_cash / (last_pv + corr_add.get(last_date, 0.0)),
    "mnst_displayed_mv": mnst[last_date][0],
    "mnst_true_mv": 2 * mnst[last_date][0],
    "mnst_cost_basis": 1887.11,
    "mnst_true_unrealized_pct": (2 * mnst[last_date][0] - 1887.11) / 1887.11,
}

out = {
    "t0": {"date": t0_date, "pv": t0_pv},
    "raw": raw,
    "corrected": cor,
    "windows": {"pre_sweep": w_pre, "post_sweep": w_post},
    "monthly_returns_corrected": monthly_rets,
    "turnover": {
        "total_buy": total_buy,
        "total_sell": total_sell,
        "strategy_buy": strat_buy,
        "strategy_sell": strat_sell,
        "sweep_buy": sweep_buy,
        "sweep_sell": sweep_sell,
        "avg_pv": avg_pv,
        "annualized_turnover_x": turnover_ann,
        "n_trades": len(trades),
    },
    "avg_cash_fraction_pre_sweep": avg_cash_frac,
    "final": final,
    "mnst_uncorrected_snapshot_dates": uncorrected,
    "dividends_accrued_total": 105.50,
}
with open(D + "metrics.json", "w") as f:
    json.dump(out, f, indent=2)

print(json.dumps(out, indent=2))
