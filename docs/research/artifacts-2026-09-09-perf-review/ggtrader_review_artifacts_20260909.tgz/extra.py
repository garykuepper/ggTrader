import json
import math

m = json.load(open("metrics.json"))
t = m["turnover"]
strat = (t["strategy_buy"] + t["strategy_sell"]) / t["avg_pv"] * (252 / 52)
print(f"strategy-only annualized turnover: {strat:.2f}x  (total {t['annualized_turnover_x']:.2f}x)")
print(f"sweep trades: buy ${t['sweep_buy']:.0f} sell ${t['sweep_sell']:.0f}")
raw_post = 103639.75395935516 / 105029.25287418172 - 1
print(f"post-sweep raw cum: {raw_post*100:.2f}%  (corrected {m['windows']['post_sweep']['cum_return']*100:.2f}%)")
sr_d = m["corrected"]["ann_sharpe"] / math.sqrt(252)
n = m["corrected"]["n_days"]
se_d = math.sqrt((1 + 0.5 * sr_d**2) / n)
print(f"Sharpe SE (annualized): ±{se_d*math.sqrt(252):.2f}")
pos = {
    "H": -86.996, "VZ": 516.618, "WM": -0.205, "AEE": -15.752, "AVB": 0.243,
    "CMI": 1.446, "CMS": -1.938, "CPB": -2.531, "CPT": -7.531, "DTE": -24.012,
    "ESS": 1.405, "EXC": -4.517, "HAS": 547.551, "HGV": -117.194, "HLT": -144.573,
    "HON": 3.932, "HRL": -5.400, "KNF": -161.565, "NKE": -21.889, "PEG": 9.498,
    "PNR": -276.737, "SPY": 123.635, "TSN": 6.448, "WLK": 58.757, "WWD": -60.042,
    "CARR": 6.589, "CIEN": 47.190, "DDOG": -21.242, "FDXF": -0.515,
    "MNST": -90.677, "YETI": -23.346,
}
srt = sorted(pos.items(), key=lambda kv: kv[1])
print("worst:", [(k, round(v)) for k, v in srt[:4]])
print("best:", [(k, round(v)) for k, v in srt[-4:]])
print(f"sum unrealized (ex-SPY): {sum(v for k, v in pos.items() if k != 'SPY'):.0f}")
print(f"n positions ex-SPY: {len(pos)-1}")
